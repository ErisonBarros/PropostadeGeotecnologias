
import React from 'react';
import { Mail, Linkedin, Github, MapPin, ExternalLink } from 'lucide-react';

function Footer() {
  const currentYear = new Date().getFullYear();

  const professionalLinks = [
    {
      name: 'Email',
      href: 'mailto:erison.barros@ufpe.br',
      icon: Mail
    },
    {
      name: 'LinkedIn',
      href: 'https://linkedin.com',
      icon: Linkedin
    },
    {
      name: 'GitHub',
      href: 'https://github.com',
      icon: Github
    },
    {
      name: 'ORCID',
      href: 'https://orcid.org',
      icon: ExternalLink
    },
    {
      name: 'Lattes',
      href: 'http://lattes.cnpq.br',
      icon: ExternalLink
    },
    {
      name: 'Portfolio',
      href: '#',
      icon: ExternalLink
    }
  ];

  return (
    <footer className="bg-secondary text-secondary-foreground border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          {/* Contact Information */}
          <div>
            <h3 className="text-xl font-semibold mb-4">Erison Barros</h3>
            <p className="text-sm mb-4 opacity-90">
              Engenheiro Cartógrafo | PhD em Engenharia Civil | Professor na UFPE
            </p>
            <div className="flex items-center gap-2 text-sm opacity-80">
              <MapPin className="w-4 h-4" />
              <span>Pernambuco – Brasil</span>
            </div>
          </div>

          {/* Professional Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Links Profissionais</h3>
            <div className="grid grid-cols-2 gap-3">
              {professionalLinks.map((link) => {
                const Icon = link.icon;
                return (
                  <a
                    key={link.name}
                    href={link.href}
                    target={link.href.startsWith('http') ? '_blank' : undefined}
                    rel={link.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                    className="flex items-center gap-2 text-sm hover:text-primary transition-colors duration-200"
                  >
                    <Icon className="w-4 h-4" />
                    <span>{link.name}</span>
                  </a>
                );
              })}
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="pt-8 border-t border-border/50 text-center">
          <p className="text-sm opacity-70">
            © {currentYear} Erison Barros. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
