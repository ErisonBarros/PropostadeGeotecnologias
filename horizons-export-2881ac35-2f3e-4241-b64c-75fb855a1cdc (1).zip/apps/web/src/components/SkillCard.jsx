
import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2 } from 'lucide-react';

function SkillCard({ category, skills, icon: Icon, index }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="bg-card border border-border rounded-xl p-6 shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all duration-300"
    >
      <div className="flex items-center gap-3 mb-4">
        {Icon && <Icon className="w-6 h-6 text-primary" />}
        <h3 className="text-lg font-semibold text-foreground">{category}</h3>
      </div>
      
      <ul className="space-y-2">
        {skills.map((skill, idx) => (
          <li key={idx} className="flex items-start gap-2 text-sm text-muted-foreground">
            <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
            <span>{skill}</span>
          </li>
        ))}
      </ul>
    </motion.div>
  );
}

export default SkillCard;
