
import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, MapPin } from 'lucide-react';

function TimelineItem({ date, institution, role, description, location, index, isLeft = false }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: isLeft ? -30 : 30 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className={`relative flex items-start gap-8 mb-12 ${isLeft ? 'md:flex-row-reverse md:text-right' : ''}`}
    >
      {/* Timeline dot */}
      <div className="hidden md:flex absolute left-1/2 -translate-x-1/2 w-4 h-4 bg-primary rounded-full ring-4 ring-background z-10"></div>
      
      {/* Content */}
      <div className={`flex-1 ${isLeft ? 'md:pr-12' : 'md:pl-12'}`}>
        <div className="bg-card border border-border rounded-xl p-6 shadow-sm hover:shadow-md transition-all duration-300">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
            <Calendar className="w-4 h-4" />
            <span className="font-medium">{date}</span>
          </div>
          
          <h3 className="text-xl font-semibold text-foreground mb-1">{role}</h3>
          <p className="text-primary font-medium mb-3">{institution}</p>
          
          {location && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
              <MapPin className="w-4 h-4" />
              <span>{location}</span>
            </div>
          )}
          
          {description && (
            <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
          )}
        </div>
      </div>
      
      {/* Mobile timeline indicator */}
      <div className="md:hidden w-4 h-4 bg-primary rounded-full ring-4 ring-background flex-shrink-0 mt-2"></div>
    </motion.div>
  );
}

export default TimelineItem;
