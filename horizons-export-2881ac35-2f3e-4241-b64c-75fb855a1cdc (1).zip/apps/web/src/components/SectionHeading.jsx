
import React from 'react';
import { motion } from 'framer-motion';

function SectionHeading({ children, className = '' }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className={`mb-12 ${className}`}
    >
      <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-3">
        {children}
      </h2>
      <div className="w-24 h-1 bg-primary rounded-full"></div>
    </motion.div>
  );
}

export default SectionHeading;
