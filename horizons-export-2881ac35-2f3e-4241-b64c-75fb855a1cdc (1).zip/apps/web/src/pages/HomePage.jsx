
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Mail, Linkedin, Github, ExternalLink, Code, Map, Satellite, Cpu, Wrench, Database } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import SectionHeading from '@/components/SectionHeading.jsx';
import TimelineItem from '@/components/TimelineItem.jsx';
import SkillCard from '@/components/SkillCard.jsx';
import ProjectCard from '@/components/ProjectCard.jsx';

function HomePage() {
  const experiences = [
    {
      date: '2015 – Presente',
      institution: 'Universidade Federal de Pernambuco (UFPE)',
      role: 'Professor Adjunto',
      location: 'Recife, PE',
      description: 'Docente no Departamento de Engenharia Cartográfica, ministrando disciplinas de Cartografia, Geodésia, Topografia e Geotecnologias. Orientação de trabalhos de conclusão de curso, iniciação científica e projetos de extensão.'
    },
    {
      date: '2015',
      institution: 'Universidade Federal de Pernambuco (UFPE)',
      role: 'Professor Substituto',
      location: 'Recife, PE',
      description: 'Atuação temporária no Departamento de Engenharia Cartográfica, ministrando disciplinas de graduação.'
    },
    {
      date: '2006 – 2015',
      institution: 'Instituto Nacional de Colonização e Reforma Agrária (INCRA)',
      role: 'Técnico em Geomática',
      location: 'Pernambuco',
      description: 'Responsável por levantamentos topográficos, georreferenciamento de imóveis rurais, análise de processos cadastrais e implementação de sistemas de informação geográfica para gestão territorial.'
    },
    {
      date: '2001 – 2015',
      institution: 'Prefeitura Municipal de Paudalho',
      role: 'Engenheiro Cartógrafo',
      location: 'Paudalho, PE',
      description: 'Desenvolvimento de projetos de cadastro técnico municipal, planejamento territorial, regularização fundiária e gestão de dados geoespaciais.'
    },
    {
      date: '2009 – Presente',
      institution: 'Conselho Regional de Engenharia e Agronomia de Pernambuco (CREA-PE)',
      role: 'Inspetor Técnico',
      location: 'Pernambuco',
      description: 'Fiscalização de atividades profissionais relacionadas à Engenharia Cartográfica, análise técnica de projetos e orientação profissional.'
    },
    {
      date: '2012 – 2015',
      institution: 'HG2 Consultoria / FADURPE',
      role: 'Instrutor de Cursos Técnicos',
      location: 'Recife, PE',
      description: 'Ministração de cursos de capacitação em Topografia, Cartografia, GPS e Geotecnologias para profissionais e estudantes.'
    }
  ];

  const education = [
    {
      date: '2022',
      institution: 'Universidade Federal de Pernambuco (UFPE)',
      role: 'Doutorado em Engenharia Civil',
      description: 'Pesquisa focada em modelagem espacial, cadastro territorial e aplicação de normas internacionais (ISO 19152) em sistemas cadastrais rurais.'
    },
    {
      date: '2009 – 2011',
      institution: 'Universidade Federal de Pernambuco (UFPE)',
      role: 'Mestrado em Ciências Geodésicas e Tecnologias da Geoinformação',
      description: 'Estudos avançados em Geodésia, Cartografia e Sistemas de Informação Geográfica.'
    },
    {
      date: '2012 – 2014',
      institution: 'Universidade Federal de Pernambuco (UFPE)',
      role: 'Especialização em Geoprocessamento',
      description: 'Aprofundamento em técnicas de análise espacial, sensoriamento remoto e aplicações de SIG.'
    },
    {
      date: '2001 – 2007',
      institution: 'Universidade Federal de Pernambuco (UFPE)',
      role: 'Graduação em Engenharia Cartográfica',
      description: 'Formação em Cartografia, Geodésia, Topografia, Fotogrametria e Sensoriamento Remoto.'
    },
    {
      date: '1996 – 1999',
      institution: 'Escola Técnica',
      role: 'Curso Técnico em Agrimensura',
      description: 'Formação técnica em levantamentos topográficos, cálculos geodésicos e desenho técnico.'
    }
  ];

  const skillCategories = [
    {
      category: 'Linguagens de Programação e Análise de Dados',
      icon: Code,
      skills: ['Python (análise espacial, automação)', 'R (estatística espacial, modelagem)', 'SQL (consultas espaciais)', 'JavaScript (webmapping)']
    },
    {
      category: 'Geotecnologias e SIG',
      icon: Map,
      skills: ['QGIS (análise espacial avançada)', 'ArcGIS (modelagem e geoprocessamento)', 'PostGIS (banco de dados espacial)', 'GRASS GIS', 'GeoDa (análise espacial)']
    },
    {
      category: 'Topografia e Cartografia',
      icon: Database,
      skills: ['Levantamentos topográficos', 'Georreferenciamento de imóveis rurais', 'Sistemas de referência e projeções cartográficas', 'Cadastro técnico multifinalitário', 'Normas técnicas (NBR, ISO)']
    },
    {
      category: 'Sensoriamento Remoto e Tecnologias Emergentes',
      icon: Satellite,
      skills: ['Drones (mapeamento aéreo)', 'Fotogrametria digital', 'LiDAR (processamento de nuvens de pontos)', 'Visão computacional', 'Processamento de imagens de satélite']
    },
    {
      category: 'Softwares e Ferramentas Técnicas',
      icon: Wrench,
      skills: ['AutoCAD (desenho técnico)', 'CloudCompare (processamento LiDAR)', 'Google Earth Engine', 'Agisoft Metashape (fotogrametria)', 'Pix4D']
    },
    {
      category: 'Tecnologias e Métodos Aplicados',
      icon: Cpu,
      skills: ['Ciência de dados geoespaciais', 'Modelagem espacial', 'Controle de qualidade cartográfica', 'Automação de processos topográficos', 'Análise multicritério']
    }
  ];

  const projects = [
    {
      title: 'Aplicação da ISO 19152 no Cadastro Rural Brasileiro',
      description: 'Pesquisa de doutorado focada na implementação do padrão internacional ISO 19152 (LADM - Land Administration Domain Model) em sistemas cadastrais rurais, visando melhorar a gestão territorial e a interoperabilidade de dados.',
      technologies: ['ISO 19152', 'LADM', 'Cadastro Rural', 'Modelagem de Dados']
    },
    {
      title: 'Sistema de Qualidade do SIGEF',
      description: 'Desenvolvimento de metodologias e ferramentas para controle de qualidade de dados geoespaciais no Sistema de Gestão Fundiária (SIGEF) do INCRA, garantindo precisão e conformidade técnica.',
      technologies: ['SIGEF', 'Controle de Qualidade', 'Georreferenciamento', 'Python']
    },
    {
      title: 'Modelagem Espacial do Mercado Imobiliário',
      description: 'Aplicação de técnicas de análise espacial e modelagem estatística para compreender padrões de valorização imobiliária e dinâmicas territoriais urbanas.',
      technologies: ['Análise Espacial', 'R', 'Modelagem Estatística', 'SIG']
    },
    {
      title: 'Mapeamento com Drones e Fotogrametria',
      description: 'Projetos de mapeamento aéreo utilizando VANTs (drones) e técnicas fotogramétricas para geração de ortomosaicos, modelos digitais de terreno e nuvens de pontos.',
      technologies: ['Drones', 'Fotogrametria', 'Pix4D', 'Agisoft Metashape']
    },
    {
      title: 'Automação de Processos Topográficos',
      description: 'Desenvolvimento de scripts e ferramentas em Python para automatizar cálculos topográficos, processamento de dados de campo e geração de relatórios técnicos.',
      technologies: ['Python', 'Automação', 'Topografia', 'QGIS']
    },
    {
      title: 'Estudos de Impacto Ambiental',
      description: 'Elaboração de estudos ambientais utilizando geotecnologias para análise de impactos territoriais, planejamento de uso do solo e monitoramento ambiental.',
      technologies: ['SIG', 'Sensoriamento Remoto', 'Análise Ambiental']
    },
    {
      title: 'Plataforma COVIDecart',
      description: 'Desenvolvimento de plataforma web para visualização e análise de dados espaciais relacionados à pandemia de COVID-19, integrando dados epidemiológicos e territoriais.',
      technologies: ['WebGIS', 'JavaScript', 'Análise Espacial', 'Visualização de Dados']
    },
    {
      title: 'Planejamento Territorial de Caruaru',
      description: 'Projeto de planejamento urbano e territorial para o município de Caruaru-PE, envolvendo análise espacial, zoneamento e propostas de ordenamento territorial.',
      technologies: ['Planejamento Urbano', 'SIG', 'Análise Territorial', 'QGIS']
    }
  ];

  return (
    <>
      <Helmet>
        <title>Erison Barros - Engenheiro Cartógrafo | PhD | Professor UFPE</title>
        <meta name="description" content="Currículo profissional de Erison Barros, Engenheiro Cartógrafo, PhD em Engenharia Civil e Professor na UFPE. Especialista em geotecnologias, cadastro territorial e inovação geoespacial." />
      </Helmet>

      <Header />

      <main className="min-h-screen">
        {/* Hero Section */}
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
          {/* Background Image with Overlay */}
          <div className="absolute inset-0 z-0">
            <img
              src="https://images.unsplash.com/photo-1703232638302-36eae109c4cb"
              alt="Topographic map with contour lines representing cartographic engineering and geospatial analysis"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-br from-background/95 via-background/90 to-background/80"></div>
          </div>

          {/* Content */}
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-foreground mb-6">
                Erison Barros
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground mb-4">
                Engenheiro Cartógrafo | PhD em Engenharia Civil | Professor na UFPE
              </p>
              <p className="text-lg text-muted-foreground max-w-3xl mx-auto mb-8">
                Especialista em geotecnologias, cadastro territorial e inovação geoespacial, 
                com foco em pesquisa aplicada e desenvolvimento de soluções para gestão territorial.
              </p>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5, duration: 0.8 }}
                className="flex items-center justify-center gap-4"
              >
                <a
                  href="#contact"
                  className="px-8 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 active:scale-[0.98] transition-all duration-200"
                >
                  Entre em Contato
                </a>
                <a
                  href="#projects"
                  className="px-8 py-3 bg-secondary text-secondary-foreground rounded-lg font-medium hover:bg-secondary/80 active:scale-[0.98] transition-all duration-200"
                >
                  Ver Projetos
                </a>
              </motion.div>
            </motion.div>
          </div>

          {/* Scroll Indicator */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1, duration: 0.8 }}
            className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10"
          >
            <div className="w-6 h-10 border-2 border-primary rounded-full flex items-start justify-center p-2">
              <motion.div
                animate={{ y: [0, 12, 0] }}
                transition={{ duration: 1.5, repeat: Infinity }}
                className="w-1.5 h-1.5 bg-primary rounded-full"
              ></motion.div>
            </div>
          </motion.div>
        </section>

        {/* About Section */}
        <section id="about" className="py-20 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <SectionHeading>Sobre</SectionHeading>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="prose prose-lg max-w-none"
            >
              <p className="text-lg text-muted-foreground leading-relaxed mb-6">
                Engenheiro Cartógrafo com mais de 20 anos de experiência profissional, atuando nas áreas de 
                Topografia, Geodésia, Cartografia, Cadastro Territorial e Geotecnologias. Doutor em Engenharia 
                Civil pela Universidade Federal de Pernambuco (UFPE), com pesquisa focada em modelagem espacial, 
                cadastro territorial e aplicação de normas internacionais em sistemas cadastrais.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed mb-6">
                Atualmente, atuo como Professor Adjunto no Departamento de Engenharia Cartográfica da UFPE, 
                onde ministro disciplinas de graduação e oriento trabalhos acadêmicos. Minha trajetória profissional 
                inclui experiências no setor público (INCRA, Prefeitura Municipal) e privado, com foco em 
                georreferenciamento de imóveis rurais, cadastro técnico multifinalitário, planejamento territorial 
                e desenvolvimento de sistemas de informação geográfica.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Tenho interesse especial em pesquisa aplicada, inovação tecnológica e desenvolvimento de soluções 
                geoespaciais para problemas reais, integrando conhecimentos de Cartografia, Ciência de Dados, 
                Sensoriamento Remoto e Tecnologias Emergentes (drones, LiDAR, visão computacional).
              </p>
            </motion.div>
          </div>
        </section>

        {/* Experience Section */}
        <section id="experience" className="py-20 bg-muted">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <SectionHeading>Experiência Profissional</SectionHeading>
            
            {/* Timeline */}
            <div className="relative">
              {/* Timeline line (desktop only) */}
              <div className="hidden md:block absolute left-1/2 top-0 bottom-0 w-0.5 bg-border -translate-x-1/2"></div>
              
              {/* Timeline items */}
              <div className="space-y-0">
                {experiences.map((exp, index) => (
                  <TimelineItem
                    key={index}
                    date={exp.date}
                    institution={exp.institution}
                    role={exp.role}
                    location={exp.location}
                    description={exp.description}
                    index={index}
                    isLeft={index % 2 === 0}
                  />
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Education Section */}
        <section id="education" className="py-20 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <SectionHeading>Formação Acadêmica</SectionHeading>
            
            <div className="space-y-6">
              {education.map((edu, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="bg-card border border-border rounded-xl p-6 shadow-sm hover:shadow-md transition-all duration-300"
                >
                  <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-foreground mb-1">{edu.role}</h3>
                      <p className="text-primary font-medium mb-2">{edu.institution}</p>
                      <p className="text-sm text-muted-foreground leading-relaxed">{edu.description}</p>
                    </div>
                    <div className="text-sm text-muted-foreground font-medium md:text-right flex-shrink-0">
                      {edu.date}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Skills Section */}
        <section id="skills" className="py-20 bg-muted">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <SectionHeading>Competências Técnicas</SectionHeading>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {skillCategories.map((category, index) => (
                <SkillCard
                  key={index}
                  category={category.category}
                  skills={category.skills}
                  icon={category.icon}
                  index={index}
                />
              ))}
            </div>
          </div>
        </section>

        {/* Projects Section */}
        <section id="projects" className="py-20 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <SectionHeading>Projetos e Pesquisas</SectionHeading>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {projects.map((project, index) => (
                <ProjectCard
                  key={index}
                  title={project.title}
                  description={project.description}
                  technologies={project.technologies}
                  index={index}
                />
              ))}
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-20 bg-muted">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <SectionHeading>Contato</SectionHeading>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="max-w-3xl mx-auto"
            >
              <div className="bg-card border border-border rounded-xl p-8 shadow-sm">
                <p className="text-lg text-muted-foreground mb-8 text-center">
                  Estou disponível para colaborações acadêmicas, projetos de pesquisa e consultorias técnicas 
                  nas áreas de Cartografia, Geotecnologias e Cadastro Territorial.
                </p>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                  <a
                    href="mailto:erison.barros@ufpe.br"
                    className="flex items-center gap-3 p-4 bg-muted rounded-lg hover:bg-muted/80 transition-all duration-200"
                  >
                    <Mail className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-sm font-medium text-foreground">Email</p>
                      <p className="text-xs text-muted-foreground">erison.barros@ufpe.br</p>
                    </div>
                  </a>
                  
                  <a
                    href="https://linkedin.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 p-4 bg-muted rounded-lg hover:bg-muted/80 transition-all duration-200"
                  >
                    <Linkedin className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-sm font-medium text-foreground">LinkedIn</p>
                      <p className="text-xs text-muted-foreground">Perfil Profissional</p>
                    </div>
                  </a>
                  
                  <a
                    href="https://github.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 p-4 bg-muted rounded-lg hover:bg-muted/80 transition-all duration-200"
                  >
                    <Github className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-sm font-medium text-foreground">GitHub</p>
                      <p className="text-xs text-muted-foreground">Repositórios</p>
                    </div>
                  </a>
                  
                  <a
                    href="https://orcid.org"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 p-4 bg-muted rounded-lg hover:bg-muted/80 transition-all duration-200"
                  >
                    <ExternalLink className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-sm font-medium text-foreground">ORCID</p>
                      <p className="text-xs text-muted-foreground">Publicações</p>
                    </div>
                  </a>
                  
                  <a
                    href="http://lattes.cnpq.br"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 p-4 bg-muted rounded-lg hover:bg-muted/80 transition-all duration-200"
                  >
                    <ExternalLink className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-sm font-medium text-foreground">Lattes</p>
                      <p className="text-xs text-muted-foreground">Currículo CNPq</p>
                    </div>
                  </a>
                  
                  <a
                    href="#"
                    className="flex items-center gap-3 p-4 bg-muted rounded-lg hover:bg-muted/80 transition-all duration-200"
                  >
                    <ExternalLink className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-sm font-medium text-foreground">Portfolio</p>
                      <p className="text-xs text-muted-foreground">Trabalhos</p>
                    </div>
                  </a>
                </div>
                
                <div className="text-center">
                  <p className="text-sm text-muted-foreground">
                    📍 Pernambuco – Brasil
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
}

export default HomePage;
